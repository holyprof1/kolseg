<?php get_header(); ?>
<main>
  <section class="hero hero-home hero-home-clean">
    <div class="hero-media">
      <img src="<?php echo esc_url(kolseg_get_theme_image('kolseg_hero_bg', 'live-studio-main.jpg')); ?>" alt="KOLSEG live studio setup">
    </div>
    <div class="hero-overlay"></div>
    <div class="container hero-clean-grid">
      <div class="hero-clean-copy reveal">
        <p class="eyebrow">Making Imagination A Statement</p>
        <h1><?php echo esc_html(get_theme_mod('kolseg_hero_title', 'Full-service design, media, sound, lighting, fabrication, interiors, and event production.')); ?></h1>
        <p class="hero-text"><?php echo esc_html(get_theme_mod('kolseg_hero_text', 'KOLSEG creates stages, backdrops, pavilions, studio content, portrait work, sound systems, lighting experiences, interiors, and launch-ready environments with the technical ability to deliver the spectacular.')); ?></p>
        <div class="hero-actions">
          <a class="button button-primary" href="<?php echo esc_url(home_url('/services/')); ?>">See Popular Categories</a>
          <a class="button button-secondary" href="<?php echo esc_url(home_url('/services/')); ?>">View All Services</a>
        </div>
      </div>
      <div class="hero-clean-stack reveal">
        <a class="hero-stack-card large" href="<?php echo esc_url(home_url('/portfolio/')); ?>">
          <img src="<?php echo esc_url(kolseg_get_theme_image('kolseg_hero_main_card', 'live-studio-stage.jpg')); ?>" alt="KOLSEG live studio stage">
          <div class="hero-stack-overlay"><strong>Main Studio</strong><span>Live sessions, recordings, rehearsals, and intimate events.</span></div>
        </a>
        <a class="hero-stack-card" href="<?php echo esc_url(home_url('/services/photography-videography/')); ?>">
          <img src="<?php echo esc_url(kolseg_get_theme_image('kolseg_hero_photo_card', 'photo-hanna-4.jpg')); ?>" alt="KOLSEG photography">
          <div class="hero-stack-overlay"><strong>Photography / Videography</strong><span>Portraits, campaign looks, and visual storytelling.</span></div>
        </a>
        <a class="hero-stack-card" href="<?php echo esc_url(home_url('/services/lighting/')); ?>">
          <img src="<?php echo esc_url(kolseg_get_theme_image('kolseg_hero_light_card', 'lighting-stage.jpg')); ?>" alt="KOLSEG lighting service">
          <div class="hero-stack-overlay"><strong>Lighting</strong><span>Concert mood, venue drama, and technical control.</span></div>
        </a>
      </div>
    </div>
  </section>

  <section class="info-strip">
    <div class="container info-strip-grid reveal">
      <article class="info-chip"><span>Experience</span><strong>Over a decade of design, production, and event execution.</strong></article>
      <article class="info-chip"><span>Coverage</span><strong>Media, sound, lighting, interior work, stage sets, fabrication, agency, and renting.</strong></article>
      <article class="info-chip"><span>Strength</span><strong>Concept, technical delivery, and physical execution under one workflow.</strong></article>
      <article class="info-chip"><span>Base</span><strong>Sango-Ota, Ogun State, serving projects across Nigeria and beyond.</strong></article>
    </div>
  </section>
</main>
<?php get_footer(); ?>

